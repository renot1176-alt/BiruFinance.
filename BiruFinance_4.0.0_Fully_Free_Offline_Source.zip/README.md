# BiruFinance 4.0.0 — Fully Free Offline Edition

## Perubahan utama
- Menghapus integrasi AI Cloud, endpoint, token, dan proxy Worker.
- Menghapus izin INTERNET dari AndroidManifest.
- Smart Import menyediakan tombol **Ambil Foto** (kamera belakang) dan **Pilih Galeri**.
- OCR teks cetak tetap diproses lokal menggunakan Google ML Kit on-device.
- Aksi Cepat menjadi 4 tombol: Tambah, Kurangi, Kalkulator, Smart Import.
- Transfer antar-dompet tetap tersedia melalui menu Dompet; hanya dihilangkan dari Aksi Cepat.
- Menambahkan transisi halaman dan animasi tekan yang ringan dengan target 60 FPS pada perangkat yang mendukung.
- Mempertahankan transaksi, dompet, transfer, anggaran, tabungan, laporan, kalkulator, backup JSON, ekspor CSV, personalisasi, dan widget tambah cepat dari 3.6.0.

## Fitur roadmap berikutnya (belum diimplementasikan dalam build 4.0.0 ini)
1. Kalender keuangan.
2. Transaksi berulang dan pengingat lokal.
3. Utang dan piutang.
4. Kategori transaksi kustom.
5. Statistik keuangan lebih lengkap.
6. Catatan keuangan.
7. Ekspor laporan PDF.

Fitur roadmap akan dikembangkan bertahap pada versi 4.x setelah fondasi 4.0.0 diuji.

## Build APK lewat GitHub Actions dari HP
1. Ekstrak ZIP ini.
2. Upload seluruh isi folder hasil ekstrak ke root repository GitHub (bukan folder ZIP sebagai satu file).
3. Pastikan folder tersembunyi `.github/workflows/build-apk.yml` ikut terunggah.
4. Commit ke branch `main`.
5. Buka tab **Actions** → **Build BiruFinance 4.0 Offline APK** → **Run workflow**.
6. Jika build berstatus hijau, buka hasil run dan unduh artifact `BiruFinance-4.0.0-Offline-debug-APK`.
7. Ekstrak artifact dan pasang `app-debug.apk`.

## Catatan penting
- Ini source APK debug untuk pengujian pribadi, bukan release bertanda tangan Play Store.
- Build belum dinyatakan berhasil sampai GitHub Actions selesai hijau.
- OCR memakai model ML Kit yang sudah menjadi dependency aplikasi; perangkat memerlukan koneksi pertama kali hanya jika model belum tersedia pada perangkat, tergantung distribusi model ML Kit. Setelah model tersedia, pemrosesan gambar berlangsung di perangkat. Untuk mengurangi ketergantungan unduhan model awal, uji pada HP target.
- Pembuatan foto memakai input kamera Android WebView dengan `capture=environment`. Dukungan pemilih kamera dapat berbeda menurut versi Android/WebView.
- Data tetap disimpan pada localStorage WebView. Buat backup JSON sebelum mengganti APK atau membersihkan data aplikasi.
- Jangan uninstall versi lama sebelum backup. Peningkatan versionCode memungkinkan instalasi di atas versi lama dengan data aplikasi yang sama, tetapi tetap backup dahulu.
