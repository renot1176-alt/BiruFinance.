package com.birufinance.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.view.View;
import android.widget.Toast;
import android.graphics.Color;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import org.json.JSONArray;

public class MainActivity extends Activity { 
private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    public static final String EXTRA_WIDGET_ACTION = "birufinance_widget_action";
    private boolean pageReady = false;
    private String pendingWidgetAction = null;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(4, 73, 190));
        getWindow().setNavigationBarColor(Color.rgb(4, 55, 150));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 74, 194));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new BiruNative(), "BiruNative");
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = true;
                dispatchWidgetAction();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
        setContentView(webView);
        pendingWidgetAction = getIntent().getStringExtra(EXTRA_WIDGET_ACTION);
        webView.loadUrl("file:///android_asset/index.html");
    }


    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        pendingWidgetAction = intent.getStringExtra(EXTRA_WIDGET_ACTION);
        dispatchWidgetAction();
    }

    private void dispatchWidgetAction() {
        if (!pageReady || pendingWidgetAction == null || webView == null) return;
        final String action = pendingWidgetAction.equals("income") ? "income" : "expense";
        pendingWidgetAction = null;
        webView.postDelayed(() -> webView.evaluateJavascript(
            "if (typeof openTx === 'function') { go('transactions'); openTx('" + action + "'); }", null), 450);
    }

    public class BiruNative {
        @JavascriptInterface public void shareText(String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(intent, "Bagikan data BiruFinance"));
            });
        }
        @JavascriptInterface public String appVersion() { return "4.0.0"; }
    }

    public class AndroidBridge {
        @JavascriptInterface public void recognizeImage(String base64Data) {
            try {
                String raw = base64Data == null ? "" : base64Data.substring(base64Data.indexOf(",") + 1);
                byte[] bytes = Base64.decode(raw, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) throw new Exception("Gambar tidak dapat dibaca");
                InputImage image = InputImage.fromBitmap(bitmap, 0);
                TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
                recognizer.process(image)
                    .addOnSuccessListener(result -> {
                        String text = result.getText();
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.onSmartOcrResult && window.onSmartOcrResult(" + JSONObject.quote(text) + ")", null));
                        recognizer.close();
                        bitmap.recycle();
                    })
                    .addOnFailureListener(error -> {
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.onSmartOcrError && window.onSmartOcrError(" + JSONObject.quote(error.getMessage() == null ? "Gagal membaca gambar" : error.getMessage()) + ")", null));
                        recognizer.close();
                        bitmap.recycle();
                    });
            } catch (Exception e) {
                final String msg = e.getMessage() == null ? "Gagal memproses gambar" : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onSmartOcrError && window.onSmartOcrError(" + JSONObject.quote(msg) + ")", null));
            }
        }
        @JavascriptInterface public void saveFile(String base64Data, String fileName, String mimeType) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                        values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "application/octet-stream" : mimeType);
                        values.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
                        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new Exception("Gagal membuat file");
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                    } else {
                        File dir = getExternalFilesDir(null);
                        if (dir == null) throw new Exception("Folder penyimpanan tidak tersedia");
                        try (FileOutputStream out = new FileOutputStream(new File(dir, fileName))) { out.write(bytes); }
                    }
                    Toast.makeText(MainActivity.this, "File disimpan: " + fileName, Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack()", null);
        else super.onBackPressed();
    }
}
