# Checklist uji Biru Finance 3.0

## Build dan instalasi
- [ ] Jalankan GitHub Actions dan pastikan `assembleDebug` sukses.
- [ ] Unduh artifact `BiruFinance-3.0.0-debug-APK` dan instal APK pada Android 6+.
- [ ] Pastikan ikon berlian, splash animation, soundtrack, dan dashboard tampil benar.
- [ ] Pastikan aplikasi dapat dibuka tanpa koneksi internet.

## Transaksi dan saldo
- [ ] Tambah pemasukan dan pastikan saldo dompet bertambah.
- [ ] Tambah pengeluaran dan pastikan saldo dompet berkurang.
- [ ] Edit transaksi pada dompet yang sama dan dompet berbeda; pastikan saldo diperbarui satu kali.
- [ ] Hapus transaksi dan pastikan saldo dikembalikan.
- [ ] Uji tanggal transaksi dan ringkasan bulan berjalan.
- [ ] Uji pencarian dan filter pemasukan/pengeluaran.

## Dompet, anggaran, tabungan
- [ ] Tambah dompet dan transfer saldo antar-dompet.
- [ ] Pastikan transfer tidak mengubah total saldo gabungan.
- [ ] Tambah, ubah, dan hapus anggaran; uji status saat melewati batas.
- [ ] Buat target tabungan, tambah kontribusi, dan hapus target.

## Laporan dan alat
- [ ] Periksa laporan, selisih bersih, grafik enam bulan, dan kategori pengeluaran.
- [ ] Uji kalkulator operasi dasar, persentase, dan penggunaan hasil ke transaksi.
- [ ] Ekspor CSV ke folder Download.
- [ ] Buat backup JSON, pulihkan dari file, dan pastikan data kembali.
- [ ] Uji pemulihan file backup dari versi BiruFinance lama.
- [ ] Uji sembunyikan nominal, efek suara, dan getaran.
- [ ] Uji navigasi swipe, navigasi bawah, tombol kembali Android, dan rotasi/ukuran layar.

## Catatan
- [ ] Uji di perangkat fisik dan catat setiap bug sebelum menandai rilis stabil.
