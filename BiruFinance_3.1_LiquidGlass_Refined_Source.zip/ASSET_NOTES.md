# Asset notes
- `aurora_bg.jpg`: original locally generated blue aurora background texture used by the app stylesheet.
- `intro_soundtrack.wav`: original synthesized opening soundtrack bundled for offline playback.
- `app/src/main/res/mipmap-*/ic_launcher.png`: Android launcher icons derived from the supplied BiruFinance blue-diamond icon reference.
- `docs/reference-dashboard.jpg` and `docs/reference-icon.jpg`: documentation-only compressed visual references; they are not copied into APK runtime assets.
- No remote fonts, trackers, analytics, or runtime CDN dependencies are used.
